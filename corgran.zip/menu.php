<div id="main-nav" class="stellarnav full">
	<ul>
	    <li>
	        <a href="index.php"><h6><i class="fas fa-home"></i>INICIO</h6></a>
	    </li>
	    <li>
	        <a href="noticias.php"><h6><i class="fas fa-newspaper"></i>NOTICIAS</h6></a>
	    </li>
		<li>
		    <a href="quienessomos.php"><h6><i class="fas fa-info-circle"></i>NOSOTROS</h6></a>
	    	<ul>
	    		<li>
	    		    <a href="quienessomos.php"><h6><i class="fas fa-university"></i>QUIENES SOMOS</h6></a>
	    		</li>
	    		<li>
	    		    <a href="contacto.php"><h6><i class="fas fa-envelope"></i>CONTACTO</h6></a>
	    		</li>
	    	</ul>
	    </li>
	    <li>
	        <a href="descargas.php"><h6><i class="fas fa-download"></i></i>DESCARGAS</h6></a>
	    </li>
	    <li>
	        <a href="ingresar.php"><h6><i class="fas fa-sign-in-alt"></i>INGRESAR</h6></a>
	    </li>
	</ul>
</div>