
<?php

    require_once 'header.php';
?>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<form role="form" id="form_usuario" method="POST" action="usuario.php">
				<div class="form-group">
					 
					<label for="exampleInputEmail1">
					    Nombre
					</label>
					<input id="nombre" type="text" class="form-control" name="nombre" />
				</div>
				<div class="form-group">
					 
					<label for="exampleInputPassword1">
						Clave
					</label>
					<input id="clave" type="password" class="form-control" name="clave" />
					
				</div>
				<div class="form-group">
    			    <label for="exampleInputPassword1">
    						Tipo usuario
    				</label>
                    <div class="btn-group">
                          <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Seleccionar
                          </button>
                          <div class="dropdown-menu">
                              <a name="a" class="dropdown-item" href="#">Colegiado</a>
                              <a name="a"class="dropdown-item" href="#">Administrador</a>
                              <a name="a"class="dropdown-item" href="#">Tesorero</a>
                          </div>
                    </div>
                </div>
		<button type="submit" class="btn btn-primary" id="guardarUsu">Guardar</button>
                </form>
		</div>
	</div>
</div>
</body>
</html>
