<div id="main-nav" class="stellarnav full">
	<ul>
	    <li>
	        <a href="index.php"><h6><i class="fas fa-home"></i>INICIO</h6></a>
	    </li>
	    <li>
	        <a href="noticias.php"><h6><i class="fas fa-newspaper"></i>NOTICIAS</h6></a>
	    </li>
		<li>
		    <a href="quienessomos.php"><h6><i class="fas fa-info-circle"></i>NOSOTROS</h6></a>
	    	<ul>
	    		<li>
	    		    <a href="quienessomos.php"><h6><i class="fas fa-university"></i>QUIENES SOMOS</h6></a>
	    		</li>
	    		<li>
	    		    <a href="contacto.php"><h6><i class="fas fa-envelope"></i>CONTACTO</h6></a>
	    		</li>
	    	</ul>
	    </li>
	    <li>
	        <a href="descargas.php"><h6><i class="fas fa-download"></i></i>DESCARGAS</h6></a>
	    </li>
	    <li>
	        <a href="micuenta.php"><h6><i class="fas fa-users-cog"></i>MI CUENTA</h6></a>
	        <ul>
	    		<li>
	    		    <a href="micuenta.php"><h6><i class="fas fa-money-check-alt"></i>COLEGIACION</h6></a>
	    		</li>
	    		<li>
	    		    <a href="misdatos.php"><h6><i class="fas fa-user-alt"></i>MIS DATOS</h6></a>
	    		</li>
	    	</ul>
	    </li>
	    <li>
	        <a href="http://corgran.slamcoop.com"><h6><i class="fas fa-comments"></i>FORO</h6></a>
	    </li>
	</ul>
</div>