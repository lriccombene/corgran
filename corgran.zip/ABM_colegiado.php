<?php
    //require_once 'header.php';
    require_once 'clases/colegiado.php';
?>
<?php
	$obj_colegiado = new app\clases\colegiado; // 

?>