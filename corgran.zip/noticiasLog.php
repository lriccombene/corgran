                <div class="col-sm-6">
                    <div class="card-body mb-3 card-background">
                        <img class="card-img-top img-fluid" src="img/noticia4.jpg">
				    	<h5 class="card-title"><a href="#">Diplomatura en Diabetes y Nutrición</a></h5>
				    	<p class="card-text">Inicia 21 de Abril 2018 c. Inscripciones Abiertas . Cupo limitado.</p>
				    	<a href="#" class="btn btn-primary rounded-0 mb-3">Leer mas...</a>
				    	<div class="card-footer text-muted">
                        24/02/2018
                        </div>
                    </div>
                </div>