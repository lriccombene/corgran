<?php
    require_once 'header.php';
?>
<!-- /HEADER -->
    <div class="w-screen d-block hidden-sm-down mb-3">
        
    </div>
	<div class="container-fluid">
		<div class="row mb-3">
			<div class="col-lg-9">
			    <h5>Quienes somos</h5>
			    <hr>
			    <div class="row mb-3">
			        <div class="col-md-6">
			            <div class="card-body card-background">
    			            <h6>Sobre el Colegio</h6>
    			            <p class="text-justify font-italic lead">Graduados en nutrición matriculados en cumplimiento de la ley Nº 4793 de la provincia de Rio Negro, comprometidos con el ejercicio ético de la profesión. Con títulos de Dietistas, Nutricionistas-Dietistas, Licenciados en Nutrición y todo otro título que requiera los conocimientos y formación académica referida a las ciencias de la nutrición.</p>
    			            <h6>Funciones y Atribuciones</h6>
    			            <div id="carouselFunciones" class="carousel slide" data-ride="carousel">
    			                <a class="" href="#carouselFunciones" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Anterior</span>
                                </a>
                                <a class="" href="#carouselFunciones" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Siguiente</span>
                                </a>
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <ul>
                                            <li>a. Representar profesionalmente a todos los matriculados ante los poderes públicos, colegios profesionales, entidades nutricionales provinciales, nacionales e internacionales.</li>
                                            <li>b. Mantener un registro de inscriptos debidamente actualizado, comunicando a las instituciones y organismos pertinentes.</li>
                                            <li>c. Velar y exigir el cumplimiento de las disposiciones de la ley G nº 4011, la presente y los reglamentos que en su consecuencia se dicten.</li>
                                        </ul>
                                    </div>
                                    <div class="carousel-item">
                                        <ul>
                                            <li>d. Ejercer el poder disciplinario sobre los profesionales inscriptos.</li>
                                            <li>e. Denunciar el ejercicio ilegal de la profesión por parte de personas no matriculadas ante las autoridades que correspondan.</li>
                                            <li>f. Sancionar el Estatuto del Colegio y el Código de Etica Profesional.</li>
                                            <li>g. Contribuir al mejoramiento de la carrera universitaria de nutrición, conviniendo con universidades del país o del extranjero, la realización de actividades científicas y culturales.</li>
                                        </ul>
                                    </div>
                                    <div class="carousel-item">
                                        <ul>
                                            <li>h. Instituir becas y/o premios estímulos a los estudiantes universitarios de las carreras colegiadas, conforme a las reglamentaciones que a tales efectos se dicten por la asamblea, propiciando la investigación científica.</li>
                                            <li>i. Organizar, subvencionar, auspiciar, patrocinar y/o participar en congresos, conferencias y reuniones que se realicen con fines útiles a la profesión.</li>
                                            <li>j. El Colegio no podrá inmiscuirse u opinar en cuestiones de carácter político, religioso o de cualquier otra índole que sea ajena al cumplimiento específico de los fines de la presente ley.</li>
                                            
                                        </ul>
                                    </div>
                                    <div class="carousel-item">
                                        <ul>
                                            <li>k. Confeccionar y mantener actualizado un legajo de cada profesional inscripto.</li>
                                            <li>l. Velar por la armonía entre los profesionales inscriptos, promoviendo el arbitraje para dirimir conflictos entre ellos y/o terceros.</li>
                                            <li>m. Realizar cualquier acto encaminado al logro de los objetivos propuestos en esta ley.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
    	                </div>
			        </div>
			        <div class="col-md-6">
			            <div class="card-body card-background">
                            <h6>Autoridades Actuales</h6>
                            <div class="row">
    			                <div class="col-sm-6">
    			                    <p><strong>Consejo Directivo Provincial</strong></p>
    			                    <ul>
    			                        <li>Presidente: Lascano Sonia Andrea</li>
    			                        <li>Vicepresidente: Suarez Adriana Edith</li>
    			                        <li>Secretaria: Menna Lorena Mercedes</li>
    			                        <li>Tesorera: Salgado Agustina Ines</li>
    			                        <li>1 Vocales Titulares: Ferrer Julia Mercedes</li>
    			                        <li>2 Vocales Titulares: Yearson Alejandra</li>
    			                        <li>1 Vocal Suplente: Melis María Julieta</li>
    			                        <li>2 Vocal Suplente: Rossi Luciana</li>
    			                    </ul>
    			                </div>
    			                <div class="col-sm-6">
    			                    <p><strong>Comisión Revisora de Cuentas</strong></p>
    			                    <ul>
    			                        <li>Tassara Lorena</li>
    			                        <li>Molinari María Inés</li>
    			                        <li>Suplente: Gonzalez Mariana Gisella</li>
    			                    </ul>
    			                    <p><strong>Tribunal de Ética y Disciplina</strong></p>
    			                    <ul>
    			                        <li>Córdoba Jaime Matías</li>
    			                        <li>Charro Karina Beatriz</li>
    			                        <li>García María Laura</li>
    			                        <li>Suplente: Lo Presti Antonella Noé</li>
    			                    </ul>
    			                </div>
                            </div>
		                </div>
			        </div>
			    </div>
			</div>
			<!-- SIDEBAR -->
			<div class="col-lg-3">
			    <h5>Publicidades</h5>
			    <hr>
			    <img class="img-fluid mb-3" src="img/2017-02-23-PHOTO-00000082.jpg">
			    <img class="img-fluid mb-3" src="img/publi_aca.jpg">
			    <img class="img-fluid mb-3" src="img/pastedImage.png">
				<h5>Links de interés</h5>
			    <hr>
			    <div class="accordion" id="accordionExample">
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingOne">
                            <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            AANEP
                            </button>
                            </h5>
                        </div>
                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Asociación Argentina de Nutrición Enteral y Parenteral</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingTwo">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            SAOTA
                            </button>
                            </h5>
                        </div>
                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Sociedad Argenina de Obesidad y Trastornos Alimenarios</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingThree">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            MINISTERIO DE SALUD
                            </button>
                            </h5>
                        </div>
                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Ministerio de Salud de Río Ngro</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingfour">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            FAO
                            </button>
                            </h5>
                        </div>
                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Organización de las Nacions Unidas para la Alimentación y la Agricultura</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingFive">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                            OMS
                            </button>
                            </h5>
                        </div>
                        <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Organiación Mundial de la Salud</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingSix">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                            MINISTERIO DE AGROINDUSTRIA
                            </button>
                            </h5>
                        </div>
                        <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Ministerio de Agroindustria de la Nación Argentina</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingSeven">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                            MINITERIO DE SALUD
                            </button>
                            </h5>
                        </div>
                        <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Miniterio de Salud de la Nación</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingEight">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                            SUPERINTENDENCIA DE SALUD
                            </button>
                            </h5>
                        </div>
                        <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Superintenencia de Servicios de Salud</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingNine">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                            F.A.D.
                            </button>
                            </h5>
                        </div>
                        <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Federación Argentina de Diabetes</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingTen">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                            A.N.M.A.T.
                            </button>
                            </h5>
                        </div>
                        <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Administración Nacional de Medicamenos, Alimentos y Tecnología Médica</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingEleven">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
                            OPS OMS
                            </button>
                            </h5>
                        </div>
                        <div id="collapseEleven" class="collapse" aria-labelledby="headingEleven" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Organización Panamericana de Salud - Organización Mundial de la Salud América</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingTwelve">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">
                            MEDLINE
                            </button>
                            </h5>
                        </div>
                        <div id="collapseTwelve" class="collapse" aria-labelledby="headingTwelve" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>MEDLINE - PubMed Resources Guide</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingThirteen">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThirteen" aria-expanded="false" aria-controls="collapseThirteen">
                            SCIELO
                            </button>
                            </h5>
                        </div>
                        <div id="collapseThirteen" class="collapse" aria-labelledby="headingThirteen" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Scientific Electronic Library Online</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingFourteen">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFourteen" aria-expanded="false" aria-controls="collapseFourteen">
                            FIC ARGENTINA
                            </button>
                            </h5>
                        </div>
                        <div id="collapseFourteen" class="collapse" aria-labelledby="headingFourteen" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Fundación Interamericana del Corazón Argentina</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingFifteen">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFifteen" aria-expanded="false" aria-controls="collapseFifteen">
                            FAGRAN
                            </button>
                            </h5>
                        </div>
                        <div id="collapseFifteen" class="collapse" aria-labelledby="headingFifteen" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>Federación Argentina de Graduados en Nutrición</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                    <div class="card border-0 rounded-0 card-background">
                        <div class="card-header" id="headingSixteen">
                            <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSixteen" aria-expanded="false" aria-controls="collapseSixteen">
                            CONGRESO DE NUTRICION
                            </button>
                            </h5>
                        </div>
                        <div id="collapseSixteen" class="collapse" aria-labelledby="headingSixteen" data-parent="#accordionExample">
                            <div class="card-body">
                            <p>XIII Congreso Argenino de Graduados en Nutrición</p>
                            <a href="#" class="btn btn-primary rounded-0 mb-3">Acceder</a>
                            </div>
                        </div>
                    </div>
                </div>
			</div>
			<!-- /SIDEBAR -->
		</div>
		<!-- /CONTENIDO PRINCIPAL -->
		<!-- FOOTER -->
		<div class="row footer">
		    <!-- DESTACADOS -->
    		<div class="row mb-3 mx-1">
    			<div class="col-sm-4 mb-3">
    				<!-- DESTACADO1 -->
    				<div class="card text-center border-0 mb-3">
    					<div class="card-body blanco red">
        					<h5 class="card-title">Colegiate!</h5>
        					<p class="card-text">Instrucciones y archivos necesarios para realizar el trámite</p>
        					<a href="#" class="btn btn-light rounded-0">Mas información</a>
      					</div>
    				</div>
    				<!-- /DESTACADO1 -->
    			</div>
    			<div class="col-sm-4 mb-3">
    				<!-- DESTACADO2 -->
    				<div class="card text-center border-0 mb-3">
    					<div class="card-body blanco red">
        					<h5 class="card-title">Profesionales habilitados</h5>
        					<p class="card-text">Conozca los profesionales habilitados por el Colegio Rionegrino de graduados en nutrición en la provincia de Rio Negro</p>
        					<a href="#" class="btn btn-light rounded-0">Ingresar</a>
      					</div>
    				</div>
    				<!-- /DESTACADO2 -->
    			</div>
    			<div class="col-sm-4 mb-3">
    				<!-- DESTACADO3 -->
    				<div class="card text-center border-0 mb-3">
    					<div class="card-body blanco red">
        					<h5 class="card-title">Consulte su cuenta</h5>
        					<p class="card-text">Desde nuestro portal de servicios podra informarse sobre el estado de su cuenta</p>
        					<a href="#" class="btn btn-light rounded-0">Ingresar</a>
      					</div>
    				</div>
    				<!-- /DESTACADO3 -->
    			</div>
    		    <!-- /DESTACADOS -->
        		<div class="col-sm-4 mb-3">
        		    <h5>Colegio Rionegrino de Graduados en Nutrición</h5>
    			    <hr class="blanca">
    			    <p>Ley. Nro. 4793</p>
    			    <p>Sarmiento Nº505</p>
    			    <p>Viedma. R.N.</p>
    			    <a href="mailto:info@corgran.org">info@corgran.org</a>
        		</div>
        		<div class="col-sm-4 mb-3">
        		    <h5>Últimas noticias</h5>
    			    <hr class="blanca">
    			    <a class="footer-noticias" href="#">Diplomatura en Estudios Avanzados en Diabetes Mellitus</a>
    			    <p class="rojo">marzo 13, 2018</p>
    			    <a class="footer-noticias" href="#">XIII Congreso Argentino de Graduados en Nutrición SORTEO BECAS</a>
    			    <p class="rojo">febrero 24, 2018</p>
    			    <a class="footer-noticias" href="#">Inscripción para el curso de Formación de Cuidadores Domiciliarios</a>
    			    <p class="rojo">febrero 24, 2018</p>
    			    <a class="footer-noticias" href="#">Diplomatura en Diabetes y Nutrición</a>
    			    <p class="rojo">febrero 24, 2018</p>
        		</div>
        	    <div class="col-sm-12">
        	        <hr class="blanca">
        	        <div class="card border-0 footer">
            	        <p>Copyright acá</p>
                    </div>
        	    </div>
        	</div>
    	</div>
		<!-- /FOOTER -->
    </div>
</body>
</html>